package com.example.neonrunner

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class MainActivity : AppCompatActivity() {

    // IDs de TEST Google : remplacez-les par vos vrais blocs d'annonces AdMob avant publication
    private val bannerId = "ca-app-pub-3940256099942544/6300978111"
    private val interstitialId = "ca-app-pub-3940256099942544/1033173712"

    private var interstitial: InterstitialAd? = null
    private var games = 0
    private lateinit var banner: AdView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}

        val game = GameView(this)
        banner = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = bannerId
            loadAd(AdRequest.Builder().build())
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(game, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(
                banner,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { gravity = Gravity.CENTER_HORIZONTAL }
            )
        }
        setContentView(root)

        loadInterstitial()
        game.onGameOver = {
            games++
            // Une pub plein écran toutes les 3 parties (pas à chaque fois : mauvaise expérience)
            if (games % 3 == 0) {
                interstitial?.show(this)
                interstitial = null
                loadInterstitial()
            }
        }
    }

    private fun loadInterstitial() {
        InterstitialAd.load(
            this, interstitialId, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
            }
        )
    }

    override fun onPause() { banner.pause(); super.onPause() }
    override fun onResume() { super.onResume(); banner.resume() }
    override fun onDestroy() { banner.destroy(); super.onDestroy() }
}
