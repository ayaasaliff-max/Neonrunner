package com.example.neonrunner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

class GameView(context: Context) : View(context) {

    var onGameOver: ((Int) -> Unit)? = null

    private class Obj(val type: Int, val lane: Int, var y: Float, val h: Float) { var dead = false }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val prefs = context.getSharedPreferences("nr", Context.MODE_PRIVATE)
    private var best = prefs.getInt("best", 0)

    private val objs = mutableListOf<Obj>()
    private var lane = 1
    private var px = 180f
    private var jump = 0f
    private var dist = 0f
    private var next = 0f
    private var speed = 260f
    private var t = 0f
    private var coins = 0
    private var score = 0
    private var started = false
    private var over = false
    private var last = 0L
    private var downX = 0f
    private var downY = 0f
    private var h = 640f // hauteur logique (largeur logique = 360)

    private fun laneX(i: Int) = 60f + i * 120f

    private fun reset() {
        objs.clear(); lane = 1; px = laneX(1); jump = 0f; dist = 0f; next = 0f
        speed = 260f; t = 0f; coins = 0; score = 0; started = false; over = false
    }

    private fun spawn() {
        val r = Random.nextFloat()
        val l = Random.nextInt(3)
        when {
            r < 0.4f -> objs.add(Obj(0, l, -60f, 50f))
            r < 0.7f -> objs.add(Obj(1, l, -30f, 20f))
            else -> for (i in 0 until 4) objs.add(Obj(2, l, -20f - i * 40f, 18f))
        }
    }

    private fun update(dt: Float) {
        if (!started || over) return
        val py = h - 110f
        t += dt
        speed = minOf(620f, 260f + t * 7f)
        dist += speed * dt
        score = (dist / 10f).toInt() + coins * 10
        px += (laneX(lane) - px) * minOf(1f, dt * 16f)
        if (jump > 0f) { jump += dt; if (jump > 0.7f) jump = 0f }
        next -= speed * dt
        if (next <= 0f) { spawn(); next = 170f + Random.nextFloat() * 130f }
        val air = jump > 0f
        for (o in objs) {
            o.y += speed * dt
            if (o.dead || o.lane != lane || abs(px - laneX(o.lane)) > 40f) continue
            if (o.y + o.h > py - 18f && o.y < py + 18f) {
                if (o.type == 2) { o.dead = true; coins++ }
                else if (o.type == 0 || !air) {
                    over = true
                    if (score > best) { best = score; prefs.edit().putInt("best", best).apply() }
                    onGameOver?.invoke(score)
                }
            }
        }
        objs.removeAll { it.y > h + 60f || it.dead }
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0f else minOf(0.05f, (now - last) / 1e9f)
        last = now
        val u = width / 360f
        h = height / u
        update(dt)

        canvas.save()
        canvas.scale(u, u)
        val py = h - 110f

        p.style = Paint.Style.FILL; p.color = Color.parseColor("#1b2550")
        canvas.drawRect(0f, 0f, 360f, h, p)

        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.parseColor("#3a4a8a")
            pathEffect = DashPathEffect(floatArrayOf(20f, 20f), -(dist % 40f))
        }
        canvas.drawLine(120f, 0f, 120f, h, line)
        canvas.drawLine(240f, 0f, 240f, h, line)

        p.style = Paint.Style.FILL
        for (o in objs) {
            val x = laneX(o.lane)
            when (o.type) {
                0 -> { p.color = Color.parseColor("#e94560"); canvas.drawRect(x - 40f, o.y, x + 40f, o.y + o.h, p)
                       p.color = Color.parseColor("#ff8fa3"); canvas.drawRect(x - 40f, o.y, x + 40f, o.y + 8f, p) }
                1 -> { p.color = Color.parseColor("#ffb703"); canvas.drawRect(x - 40f, o.y, x + 40f, o.y + o.h, p) }
                else -> { p.color = Color.parseColor("#ffd60a"); canvas.drawCircle(x, o.y + 9f, 9f, p) }
            }
        }

        val lift = if (jump > 0f) sin(jump / 0.7f * PI.toFloat()) * 60f else 0f
        p.color = Color.argb(90, 0, 0, 0); canvas.drawOval(px - 18f, py + 16f, px + 18f, py + 28f, p)
        p.color = Color.parseColor("#06d6a0"); canvas.drawRect(px - 16f, py - 20f - lift, px + 16f, py + 20f - lift, p)
        p.color = Color.WHITE
        canvas.drawRect(px - 9f, py - 12f - lift, px - 3f, py - 6f - lift, p)
        canvas.drawRect(px + 3f, py - 12f - lift, px + 9f, py - 6f - lift, p)

        p.textSize = 18f; p.isFakeBoldText = true
        p.textAlign = Paint.Align.LEFT
        canvas.drawText("Score $score", 12f, 30f, p)
        canvas.drawText("Pièces $coins", 12f, 54f, p)
        p.textAlign = Paint.Align.RIGHT
        canvas.drawText("Record ${maxOf(best, score)}", 348f, 30f, p)
        p.textAlign = Paint.Align.CENTER
        if (!started) {
            p.textSize = 28f; canvas.drawText("Neon Runner", 180f, 230f, p)
            p.textSize = 16f; canvas.drawText("Touchez ou glissez pour commencer", 180f, 262f, p)
        }
        if (over) {
            p.color = Color.argb(165, 0, 0, 0); canvas.drawRect(0f, 0f, 360f, h, p)
            p.color = Color.WHITE
            p.textSize = 32f; canvas.drawText("Perdu !", 180f, 240f, p)
            p.textSize = 20f; canvas.drawText("Score : $score", 180f, 278f, p)
            p.textSize = 16f; canvas.drawText("Touchez pour rejouer", 180f, 312f, p)
        }
        canvas.restore()
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y }
            MotionEvent.ACTION_UP -> {
                if (over) { reset(); return true }
                started = true
                val dx = e.x - downX
                val dy = e.y - downY
                val th = 40f * resources.displayMetrics.density / 2f
                if (abs(dx) > th && abs(dx) > abs(dy)) lane = (lane + if (dx > 0) 1 else -1).coerceIn(0, 2)
                else if (jump == 0f) jump = 0.001f
            }
        }
        return true
    }
}
